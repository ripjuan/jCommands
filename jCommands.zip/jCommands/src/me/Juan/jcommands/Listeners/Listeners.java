package me.Juan.jcommands.Listeners;

import me.Juan.jcommands.Utils.Utils;
import me.Juan.jcommands.jCommands;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class Listeners implements Listener {

    private static jCommands plugin;

    public Listeners (jCommands plugin) {
        this.plugin = plugin;

        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

}
