package me.Juan.jcommands.Commands;

import me.Juan.jcommands.Utils.Utils;
import me.Juan.jcommands.jCommands;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Fly implements CommandExecutor {

    private jCommands plugin;

    public Fly (jCommands plugin) {
        this.plugin = plugin;

    plugin.getCommand("fly").setExecutor(this);
    }

    public Fly() {

    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String s, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage(Utils.chat(plugin.getConfig().getString("console_error_message")));
            return true;
        }

        Player p = (Player) sender;

        if (p.hasPermission("jcommands.fly")) {
            if (p.isFlying()) {
                p.setAllowFlight(false);
                p.setFlying(false);
                p.sendMessage(Utils.chat(plugin.getConfig().getString("FlyCommand.flying_disabled")));
                return true;
            } else {
                p.setAllowFlight(true);
                p.setFlying(true);
                p.sendMessage(Utils.chat(plugin.getConfig().getString("FlyCommand.flying_enabled")));
            }
        } else {
            p.sendMessage(Utils.chat(plugin.getConfig().getString("no_perm_message")));
        }
        return false;
    }
}
