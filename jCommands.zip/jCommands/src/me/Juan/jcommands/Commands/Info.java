package me.Juan.jcommands.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Info implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player player = (Player) sender;
        if (sender instanceof Player){
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6&lInfo"));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&eDiscord: &fdiscord.gg/juan"));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&eWebsite: &fwww.juan.com"));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&eTwitter: &ftwitter.com/juan"));
        }
        else {
            sender.sendMessage("You cant execute commands in the console.");
        }
        return true;
    }
}
