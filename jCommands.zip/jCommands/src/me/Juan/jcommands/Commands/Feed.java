package me.Juan.jcommands.Commands;

import me.Juan.jcommands.Utils.Utils;
import me.Juan.jcommands.jCommands;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Feed implements CommandExecutor {

    private jCommands plugin;
    private int MaxFoodLevel;

    public Feed (jCommands plugin) {
        this.plugin = plugin;

        plugin.getCommand("feed").setExecutor(this);
    }

    public Feed() {

    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String s, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage(Utils.chat("&cOnly players can execute this command."));
            return true;
        }

        Player p = (Player) sender;

        if (p.hasPermission("jcommands.feed")) {

                int maxFoodLevel = 20;
                if (p.getFoodLevel() < MaxFoodLevel) {
                    p.setFoodLevel(maxFoodLevel);
                    p.sendMessage(Utils.chat("&6You have been successfully fed."));
                    return true;
                } else {
                    p.sendMessage(Utils.chat("&cYou are already full."));
                p.sendMessage(Utils.chat("&cYou dont have permissions to execute this command."));
            }
        } else {
            p.sendMessage(Utils.chat(plugin.getConfig().getString("no_perm_message")));
        }
        return false;
    }
}
