package me.Juan.jcommands;

import me.Juan.jcommands.Commands.Fly;
import me.Juan.jcommands.Commands.Help;
import me.Juan.jcommands.Commands.Info;
import me.Juan.jcommands.Commands.Media;
import org.bukkit.command.CommandExecutor;
import org.bukkit.plugin.java.JavaPlugin;
import me.Juan.jcommands.Commands.Feed;

public class jCommands extends JavaPlugin {

    public void onEnable() {
        saveDefaultConfig();
        new Fly(this);
        new Feed(this);
        System.out.println("&aBasic Commands successfully executed!");
        this.getCommand("help").setExecutor((CommandExecutor)new Help());
        this.getCommand("info").setExecutor((CommandExecutor)new Info());
        this.getCommand("Media").setExecutor((CommandExecutor)new Media());
        this.getCommand("Fly").setExecutor((CommandExecutor)new Fly());
        this.getCommand("Feed").setExecutor((CommandExecutor)new Feed());
    }

    public void onDisable() {
        System.out.println("&aBasic Commands successfully deactivated!");
    }
}